(function($) {
	Drupal.behaviors.gj_search_frm_v2 = {
		attach: function() {
      console.log(Drupal.settings.gj_search_frm_v2.subjectlevels);
      var subject_level_array = Drupal.settings.gj_search_frm_v2.subjectlevels;
      $('select[name="subject"]').change(function() {
          var subject = $(this).val();
          if(subject != "Select") {
            $("#edit-level").prop('disabled', false);
            $("#edit-level").children().remove();
            var levels = get_levels_for_subject(subject, subject_level_array)
            $.each(levels, function(key, value) {
              $('#edit-level')
                .append($("<option></option>")
                .attr("value",value)
                .text(value));
            });
          }
      });

		}
  };

  function get_levels_for_subject(subject, subject_level_array) {
    for (var i in subject_level_array) {
      if(i == subject) {
        var levels = subject_level_array[i];
        //console.log(levels);
      }
    }
    return levels;
  }


})(jQuery);
